import java.util.Scanner;

public class Pragram {
	public static void main(String[] args){
		stuMgr Mgr = new stuMgr();
		int choice = -1;
		while(choice!=0){
			Mgr.showmenu();
			choice = new Scanner(System.in).nextInt();
			switch(choice){
			case 0:break;
			case 1:Mgr.getStudents();break;
			case 2:Mgr.getTotalAndAver();break;
			case 3:Mgr.showStuAver();break;
			case 4:Mgr.sortSum();break;
			case 5:Mgr.sortSumUP();break;
			case 6:Mgr.sortID();break;
			case 7:Mgr.sortName();break;
			case 8:Mgr.findID();break;
			case 9:Mgr.findName();break;
			case 10:Mgr.Statistic();break;
			case 11:Mgr.showAllStu();break;
			}
		}
	}
}
